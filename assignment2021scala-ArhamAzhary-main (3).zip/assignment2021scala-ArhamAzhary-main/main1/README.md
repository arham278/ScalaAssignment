# assignment2021scala - Main 1

* deadline: 21 January, 5pm
* [coursework description](https://nms.kcl.ac.uk/christian.urban/main_cw01.pdf)
* reference jar:
      [drumb.jar](https://nms.kcl.ac.uk/christian.urban/drumb.jar)