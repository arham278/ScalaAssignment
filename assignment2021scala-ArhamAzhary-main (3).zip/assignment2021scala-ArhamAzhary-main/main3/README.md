# assignment2021scala - Main 3

* deadline: 21 January, 5pm
* [coursework description](https://nms.kcl.ac.uk/christian.urban/main_cw03.pdf)
* reference jar:
      [re.jar](https://nms.kcl.ac.uk/christian.urban/re.jar)