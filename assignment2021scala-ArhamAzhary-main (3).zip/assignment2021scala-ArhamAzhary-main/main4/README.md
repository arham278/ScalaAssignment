# assignment2021scala - Main 4

* deadline: 21 January, 5pm
* [coursework description](https://nms.kcl.ac.uk/christian.urban/main_cw04.pdf)
* reference jar:
     [knight1.jar](https://nms.kcl.ac.uk/christian.urban/knight1.jar),
     [knight2.jar](https://nms.kcl.ac.uk/christian.urban/knight2.jar),
     [knight3.jar](https://nms.kcl.ac.uk/christian.urban/knight3.jar)