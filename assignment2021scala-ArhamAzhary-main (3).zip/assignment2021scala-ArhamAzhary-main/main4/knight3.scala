// Finding a single tour on a "mega" board
//=========================================

object M4c {

// !!! Copy any function you need from file knight1.scala !!!
// !!! or knight2.scala                                   !!! 
//
// If you need any auxiliary function, feel free to 
// implement it, but do not make any changes to the
// templates below.


type Pos = (Int, Int)    // a position on a chessboard 
type Path = List[Pos]    // a path...a list of positions


def is_legal(dim: Int, path: Path, x: Pos) : Boolean = {

    if (x._1 > dim-1 || x._1 < 0 || x._2 > dim-1 || x._2 < 0 ) {
      false
    }
    else{
      if (path.contains(x)) {
        false
      }
      else{
        true
      }
    }
  }

//(9) Implement a function that searches for a 
//    you have to be careful to write a tail-recursive version as this 
//    function will be called with dimensions of up to 70 * 70
//    and starting field (0, 0). It has to produce a solution within
//    30 seconds.
def ordered_moves(dim: Int, path: Path, x: Pos) : List[Pos] = {
    legal_moves(dim,path,x).sortBy(legal_moves(dim,path,_).length)
}

def legal_moves(dim: Int, path: Path, x: Pos) : List[Pos] = {
    val possibleMoves = List((x._1+1,x._2+2),(x._1+2,x._2+1),(x._1+2,x._2-1),(x._1+1,x._2-2),(x._1-1,x._2-2),(x._1-2,x._2-1),(x._1-2,x._2+1),(x._1-1,x._2+2))
    for (i<-possibleMoves;if (is_legal(dim,path,i))) yield i
    //for (i<-possibleMoves;if (is_legal(dim,path)(i))) yield i
  }


def tour_on_mega_board(dim: Int, path: Path) : Option[Path] = {
    if(dim < 5) None
    else {
      if(dim*dim == path.length) Some(path)
      else tour_on_mega_board(dim,ordered_moves(dim,path,path.head).head::path)
    }
  }

}
