# assignment2021scala - Main 2

* deadline: 21 January, 5pm
* [coursework description](https://nms.kcl.ac.uk/christian.urban/main_cw02.pdf)
* reference jar:
      [danube.jar](https://nms.kcl.ac.uk/christian.urban/danube.jar)