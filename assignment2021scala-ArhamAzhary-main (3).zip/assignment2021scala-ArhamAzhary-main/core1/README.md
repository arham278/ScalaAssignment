# assignment2021scala - Core 1

* deadline: 21 January, 5pm
* [coursework description](https://nms.kcl.ac.uk/christian.urban/core_cw01.pdf)
* reference jar:
    [collatz.jar](https://nms.kcl.ac.uk/christian.urban/collatz.jar)