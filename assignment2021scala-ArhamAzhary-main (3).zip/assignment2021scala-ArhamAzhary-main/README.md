# assignment2021scala 

* deadline for all parts: 21 January, 5pm
* all parts have reference jar-implementations