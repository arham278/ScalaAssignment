# assignment2021scala - Core 3

* deadline: 21 January, 5pm
* [coursework description](https://nms.kcl.ac.uk/christian.urban/core_cw03.pdf)
* reference jar:
    [postfix.jar](https://nms.kcl.ac.uk/christian.urban/postfix.jar),
    [postfix2.jar](https://nms.kcl.ac.uk/christian.urban/postfix2.jar)