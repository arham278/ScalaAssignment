# assignment2021scala - Core 2

* deadline: 21 January, 5pm
* [coursework description](https://nms.kcl.ac.uk/christian.urban/core_cw02.pdf)
* reference jar:
    [docdiff.jar](https://nms.kcl.ac.uk/christian.urban/docdiff.jar)